package com.dxc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.model.Employee;
import com.dxc.service.EmployeeService;


@RestController
@CrossOrigin("*")
@RequestMapping("/api")
public class EmployeeRestCtrl {

	@Autowired
	EmployeeService empservice;
	
	@GetMapping("/getemployees")
	public List<Employee> getEmployee() {
		return empservice.getEmployee();
	}
	
	@GetMapping("/getemployees/{id}")
	public Employee getEmployee(@PathVariable("id") int id) {
		return empservice.getEmployeeById(id);
	}
	
	@PostMapping("/addemployee")
	public Employee saveEmployee(@RequestBody Employee user) {			
		return empservice.saveEmployee(user);
	}
	
	@PutMapping("/editemployee/{id}")
	public Employee updateEmployee(@RequestBody Employee user) {
		return empservice.updateEmployee(user);
	}
	
	@DeleteMapping("/deleteemployee/{id}")
	public void deleteEmployee(@PathVariable("id") int id) {
		empservice.deleteEmployee(id);
	}
	
	
}